/* dummy file to override one object in stdlib directory */
